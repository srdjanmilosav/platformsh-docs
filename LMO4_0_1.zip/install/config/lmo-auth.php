<?php exit(); ?>
admin|lmo|2|||