<?
/** Liga Manager Online 4
  *
  * http://lmo.sourceforge.net/
  *
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License as
  * published by the Free Software Foundation; either version 2 of
  * the License, or (at your option) any later version.
  * 
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  * General Public License for more details.
  *
  * REMOVING OR CHANGING THE COPYRIGHT NOTICES IS NOT ALLOWED!
  *
  * $Id: ini.php 305 2005-08-20 14:22:11Z jokerlmo $
  */

if (!defined('VIEWER_VERSION'))  define('VIEWER_VERSION','[<acronym title="Viewer 4.0.0 &copy; LMO-Group">&copy;</acronym>]');
require_once(PATH_TO_ADDONDIR."/classlib/ini.php");
require_once(PATH_TO_ADDONDIR."/viewer/viewer_functions.php");

























































































































if (!defined('VIEWER_VERSION')) define('VIEWER_VERSION',"Viewer Version ".VIEWER_VERSION." Addon for LMO 4<BR>Copyright &#169; 2005 <a href=\"http://www.liga-manager-online.de/\">LMO-Group</a>");
?>
