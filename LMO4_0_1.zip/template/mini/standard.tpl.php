<table style="font-size:90%;font-family:sans-serif;border-spacing:0;border-collapse:collapse;border:1px solid black;" cellspacing="0">
  <caption style="font-weight:bold;border:1px solid black;"><a style="text-decoration:underline;" href="<!--Link-->">Tabelle �</a></caption>
  <!-- BEGIN Inhalt -->
  <tr style="<!--Style-->">
    <td align="right"><!--Platz--></td>
    <td align="center"><!--TeamBild--></td>
    <td><acronym title="<!--TeamLang-->"><!--Team--></acronym></td>
    <td align="right"><!--Punkte--></td>
    <td align="right"><!--Tordifferenz--></td>
  </tr>
  <!-- END Inhalt -->
</table>