<table style="font-size:90%;font-family:sans-serif;border-spacing:0;border-collapse:collapse;border:1px solid black;" cellspacing="0">
  <caption style="font-weight:bold;border:1px solid black;"><a style="text-decoration:underline;" href="<!--Link-->">Tabelle �</a></caption>
  <!-- BEGIN Inhalt -->
  <tr style="<!--Style-->">
    <td align="right"><!--Platz--></td>
    <td><!--TeamBild-->&nbsp;<acronym title="<!--TeamLang--> (<--Team-->)"><!--TeamMittel--></acronym></td>
    <td align="right"><!--Spiele--></td>
    <td align="right"><!--Punkte--></td>
    <td><!--PlusTore-->:<!--MinusTore--></td>
    <td align="right"><!--Tordifferenz--></td>
    <td align="right"><!--Siege--></td>
    <td align="right"><!--Unentschieden--></td>
    <td align="right"><!--Niederlagen--></td>
  </tr>
  <!-- END Inhalt -->
</table>