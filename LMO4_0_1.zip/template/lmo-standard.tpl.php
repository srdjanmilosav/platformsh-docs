<table class="lmoMain" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td colspan="2" align="center"><h1><!--Titel--></h1></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><!--Newsticker--></td>
  </tr>
  <tr>
    <td class="lmoMenu" align="left"><!--Kalender--><!--Ergebnisse--><!--Tabelle--><!--Spielplan--><!--Kreuztabelle--><!--Fieberkurve--><!--Ligastatistik--><!--Spielerstatistik--><!--Tippspiel-->&nbsp;&nbsp;<td class="lmoMenu" align="right"><!--Info--></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><!--Hauptteil--></td>
  </tr>
  <tr>
    <td colspan="2" align="center"><!--Savehtml--></td>
  </tr>
  <tr>
  <td class="lmoFooter" colspan="2" align="left"><!--Sprachauswahl--></td>
  </tr>
  <tr>
    <td colspan="2">
      <table width="100%" cellspacing="0" cellpadding="0" border="0">
        <tr>
          <td valign="bottom" align="left"><!--Ligenuebersicht--></td>
          <td class="lmoFooter" valign="bottom" align="right"><!--LetzteAuswertung--><br><!--Berechnungszeit--><!--Infolink--></td>
        </tr>
	    </table>
    </td>
  </tr>
</table>