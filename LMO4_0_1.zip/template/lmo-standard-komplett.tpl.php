<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
					"http://www.w3.org/TR/html4/loose.dtd">
<html lang="de">
<head>
<title><!--Titel--></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--Stylesheet-->
</head>
<body>
  <div align="center">
    <table class="lmoMain" cellspacing="0" cellpadding="0" border="0">
      <tr>
        <td colspan="2" align="center"><h1><!--Titel--></h1></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><!--Newsticker--></td>
      </tr>
      <tr>
        <td class="lmoMenu" align="left"><!--Kalender--><!--Ergebnisse--><!--Tabelle--><!--Spielplan--><!--Kreuztabelle--><!--Fieberkurve--><!--Ligastatistik--><!--Spielerstatistik--><!--Tippspiel-->&nbsp;&nbsp;<td class="lmoMenu" align="right"><!--Info--></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><!--Hauptteil--></td>
      </tr>
      <tr>
        <td colspan="2" align="center"><!--Savehtml--></td>
      </tr>
      <tr>
        <td class="lmoFooter" colspan="2" align="left"><!--Sprachauswahl-->&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2">
          <table width="100%" cellspacing="0" cellpadding="0" border="0">
            <tr>
              <td valign="bottom" align="left"><!--Ligenuebersicht--></td>
              <td class="lmoFooter" valign="bottom" align="right"><!--LetzteAuswertung--><br><!--Berechnungszeit--><!--Infolink--></td>
            </tr>
    	    </table>
        </td>
      </tr>
    </table>
  </div>
</body>
</html>