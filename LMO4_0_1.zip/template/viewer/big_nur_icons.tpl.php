<style type="text/css">
.viewer *  {
  font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
  font-size: 8px;
}
.viewer {
  background-color: yellow;
}

.viewer a { 
  text-decoration: none;
  color: black;
  }

a:visited {
  text-decoration: none;
  color: #999;
}

.viewer table {
  background-color:#c0c0c0;
  color:black;
}

.viewer h1 {
  font-size: 8px;
  color:black;
}

.viewer .vRow {
  white-space:nowrap;
  background-color:#FFFFE0;
  color:black;
}
</style>
<table class="viewer" cellspacing="1" cellpadding="1" border="0">
  <tr>
    <th><!--Anfangsdatum-->-<!--Enddatum--></th>
  </tr>
  <tr>
    <td align="center">
      <table>
          <!-- BEGIN Liga -->
            <tr>
              <th align="left"><!--Liganame--></th>
            </tr>
            <tr>
              <td>
                <table  class="vRow" cellspacing="1" cellpadding="1" border="0" width="100%">
                  <!-- BEGIN Inhalt -->
                    <tr class="<!--Zeilenklasse-->">
                      <td><!--Datum--></td>
                      <td align="center"><!--IconBigheimalt--></td>
                      <td>&nbsp;-&nbsp;</td>
                      <td  align="center"><!--IconBiggastalt--></td>
                      <td><!--Tore--></td>
                    </tr>
                  <!-- END Inhalt -->
                </table>
                <tr>
								<td align="right"><small><!--Ligadatum--></small></td></tr>
              </td>
            </tr>
          <!-- END Liga -->
      </table>
    </td>
  </tr>
  <tr>  
  <td align="right"><small><!--VERSION--></small></td>
  </tr>
</table>